import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt

# 数据预处理和加载
data_transforms = {
    'train': transforms.Compose([
        transforms.Resize((224, 224)),                  # 调整图像大小为224x224
        transforms.ToTensor(),                           # 将图像转换为张量并归一化到[0, 1]
        transforms.Normalize([0.485, 0.456, 0.406],     # 标准化图像
                             [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])
}

data_dir = './dataset'  # 数据集目录，包含train和test子文件夹
image_datasets = {x: datasets.ImageFolder(data_dir, data_transforms[x]) for x in ['train', 'test']}
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=32, shuffle=True) for x in ['train', 'test']}

# 获取类别信息
class_names = image_datasets['train'].classes

# 模型定义及微调
model = models.resnet18(pretrained=True)  # 加载预训练的ResNet18模型
num_ftrs = model.fc.in_features
model.fc = nn.Linear(num_ftrs, 2)  # 用于猫狗二分类的全连接层

# 损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)


# 模型训练和评估
def train_model(model, criterion, optimizer, num_epochs=10):
    train_loss_history = []
    train_acc_history = []
    test_loss_history = []
    test_acc_history = []

    for epoch in range(num_epochs):
        for phase in ['train', 'test']:
            if phase == 'train':
                model.train()   # 设置模型为训练模式
            else:
                model.eval()    # 设置模型为评估模式

            running_loss = 0.0
            running_corrects = 0

            for inputs, labels in dataloaders[phase]:
                optimizer.zero_grad()   # 梯度清零

                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)

                    _, preds = torch.max(outputs, 1)

                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            epoch_loss = running_loss / len(image_datasets[phase])
            epoch_acc = running_corrects.double() / len(image_datasets[phase])

            if phase == 'train':
                train_loss_history.append(epoch_loss)
                train_acc_history.append(epoch_acc)
            else:
                test_loss_history.append(epoch_loss)
                test_acc_history.append(epoch_acc)

            print('{} Loss: {:.4f} Acc: {:.4f}'.format(phase, epoch_loss, epoch_acc))

    return model, train_loss_history, train_acc_history, test_loss_history, test_acc_history


model, train_loss, train_acc, test_loss, test_acc = train_model(model, criterion, optimizer, num_epochs=10)

# 模型推理预测
def predict_image(image_path):
    image = Image.open(image_path)  # 打开待预测的图像
    image = data_transforms['test'](image).unsqueeze(0)  # 对图像进行预处理和转换为张量

    model.eval()  # 设置模型为推理模式
    with torch.no_grad():
        output = model(image)
        _, predicted = torch.max(output, 1)

    return class_names[predicted.item()]


# 测试集和训练集准确率曲线和损失函数曲线
plt.plot(range(1, len(train_loss) + 1), train_loss, label='Training Loss')
plt.plot(range(1, len(test_loss) + 1), test_loss, label='Test Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()

plt.plot(range(1, len(train_acc) + 1), train_acc, label='Training Accuracy')
plt.plot(range(1, len(test_acc) + 1), test_acc, label='Test Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()
